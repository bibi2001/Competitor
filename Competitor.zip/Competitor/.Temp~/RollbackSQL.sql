-- Game_Admin [rel2]
alter table "APP"."GAME_ADMIN"   drop constraint "FK_GAME_ADMIN_GAME";
drop table "APP"."GAME_ADMIN";
-- Competition_Team_2 [rel12]
alter table "APP"."COMPETITION_TEAM_2"   drop constraint "FK_COMPETITION_TEAM_2_TEAM";
alter table "APP"."COMPETITION_TEAM_2"   drop constraint "FK_COMPETITION_TEAM_2_COMPETIT";
drop table "APP"."COMPETITION_TEAM_2";
-- Competition_Team [rel11]
alter table "APP"."TEAM"   drop constraint "FK_TEAM_COMPETITION";
alter table "APP"."TEAM"  drop column  "COMPETITION_OID";
-- Game_Competition [rel10]
alter table "APP"."GAME"   drop constraint "FK_GAME_COMPETITION";
alter table "APP"."GAME"  drop column  "COMPETITION_OID";
-- User_Role [rel1]
alter table "APP"."USER_ROLE"   drop constraint "FK_USER_ROLE_ROLE";
alter table "APP"."USER_ROLE"   drop constraint "FK_USER_ROLE_USER";
drop table "APP"."USER_ROLE";
-- User_Group [User2Group_Group2User]
alter table "APP"."USER_GROUP"   drop constraint "FK_USER_GROUP_GROUP";
alter table "APP"."USER_GROUP"   drop constraint "FK_USER_GROUP_USER";
drop table "APP"."USER_GROUP";
-- User_DefaultGroup [User2DefaultGroup_DefaultGroup2User]
alter table "APP"."USER"   drop constraint "FK_USER_GROUP";
alter table "APP"."USER"  drop column  "GROUP_OID";
-- Group_Module [Group2Module_Module2Group]
alter table "APP"."GROUP_MODULE"   drop constraint "FK_GROUP_MODULE_MODULE";
alter table "APP"."GROUP_MODULE"   drop constraint "FK_GROUP_MODULE_GROUP";
drop table "APP"."GROUP_MODULE";
-- Group_DefaultModule [Group2DefaultModule_DefaultModule2Group]
alter table "APP"."GROUP"   drop constraint "FK_GROUP_MODULE";
alter table "APP"."GROUP"  drop column  "MODULE_OID";
-- Competition [ent7]
drop table "APP"."COMPETITION";
-- Player [ent6]
drop table "APP"."PLAYER";
-- Team [ent5]
drop table "APP"."TEAM";
-- Role [ent4]
drop table "APP"."ROLE";
-- Game [ent3]
drop table "APP"."GAME";
-- Premium [ent2]
drop table "APP"."PREMIUM";
-- Admin [ent1]
drop table "APP"."ADMIN";
-- User [User]
drop table "APP"."USER";
-- Module [Module]
drop table "APP"."MODULE";
-- Group [Group]
drop table "APP"."GROUP";
