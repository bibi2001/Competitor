-- Group [Group]
create table "APP"."GROUP" (
   "OID"  integer  not null,
   "GROUPNAME"  varchar(255),
  primary key ("OID")
);


-- Module [Module]
create table "APP"."MODULE" (
   "OID"  integer  not null,
   "MODULEID"  varchar(255),
   "MODULENAME"  varchar(255),
  primary key ("OID")
);


-- User [User]
create table "APP"."USER" (
   "OID"  integer  not null,
   "USERNAME"  varchar(255),
   "PASSWORD"  varchar(255),
   "EMAIL"  varchar(255),
   "BIRTHDATE"  date,
   "PHONE"  varchar(255),
   "SURNAME"  varchar(255),
   "NAME"  varchar(255),
  primary key ("OID")
);


-- Admin [ent1]
create table "APP"."ADMIN" (
   "AREA"  varchar(255)
);


-- Premium [ent2]
create table "APP"."PREMIUM" (
   "ISCOMENTOR"  smallint
);


-- Game [ent3]
create table "APP"."GAME" (
   "OID"  integer  not null,
   "DESCRIPTION"  varchar(255),
   "SCORE"  varchar(255),
   "DATE"  date,
  primary key ("OID")
);


-- Role [ent4]
create table "APP"."ROLE" (
   "OID"  integer  not null,
   "NAME"  varchar(255),
  primary key ("OID")
);


-- Team [ent5]
create table "APP"."TEAM" (
   "OID"  integer  not null,
   "LOCATION"  varchar(255),
   "CREATIONDATE"  date,
   "NAME"  varchar(255),
  primary key ("OID")
);


-- Player [ent6]
create table "APP"."PLAYER" (
   "OID"  integer  not null,
  primary key ("OID")
);


-- Competition [ent7]
create table "APP"."COMPETITION" (
   "OID"  integer  not null,
   "AWARD"  varchar(255),
   "YEAR"  varchar(255),
   "LOCATION"  varchar(255),
   "NAME"  varchar(255),
   "TYPE"  varchar(255),
  primary key ("OID")
);


-- Group_DefaultModule [Group2DefaultModule_DefaultModule2Group]
alter table "APP"."GROUP"  add column  "MODULE_OID"  integer;
alter table "APP"."GROUP"   add constraint FK_GROUP_MODULE foreign key ("MODULE_OID") references "APP"."MODULE" ("OID");


-- Group_Module [Group2Module_Module2Group]
create table "APP"."GROUP_MODULE" (
   "GROUP_OID"  integer not null,
   "MODULE_OID"  integer not null,
  primary key ("GROUP_OID", "MODULE_OID")
);
alter table "APP"."GROUP_MODULE"   add constraint FK_GROUP_MODULE_GROUP foreign key ("GROUP_OID") references "APP"."GROUP" ("OID");
alter table "APP"."GROUP_MODULE"   add constraint FK_GROUP_MODULE_MODULE foreign key ("MODULE_OID") references "APP"."MODULE" ("OID");


-- User_DefaultGroup [User2DefaultGroup_DefaultGroup2User]
alter table "APP"."USER"  add column  "GROUP_OID"  integer;
alter table "APP"."USER"   add constraint FK_USER_GROUP foreign key ("GROUP_OID") references "APP"."GROUP" ("OID");


-- User_Group [User2Group_Group2User]
create table "APP"."USER_GROUP" (
   "USER_OID"  integer not null,
   "GROUP_OID"  integer not null,
  primary key ("USER_OID", "GROUP_OID")
);
alter table "APP"."USER_GROUP"   add constraint FK_USER_GROUP_USER foreign key ("USER_OID") references "APP"."USER" ("OID");
alter table "APP"."USER_GROUP"   add constraint FK_USER_GROUP_GROUP foreign key ("GROUP_OID") references "APP"."GROUP" ("OID");


-- User_Role [rel1]
create table "APP"."USER_ROLE" (
   "USER_OID"  integer not null,
   "ROLE_OID"  integer not null,
  primary key ("USER_OID", "ROLE_OID")
);
alter table "APP"."USER_ROLE"   add constraint FK_USER_ROLE_USER foreign key ("USER_OID") references "APP"."USER" ("OID");
alter table "APP"."USER_ROLE"   add constraint FK_USER_ROLE_ROLE foreign key ("ROLE_OID") references "APP"."ROLE" ("OID");


-- Game_Competition [rel10]
alter table "APP"."GAME"  add column  "COMPETITION_OID"  integer;
alter table "APP"."GAME"   add constraint FK_GAME_COMPETITION foreign key ("COMPETITION_OID") references "APP"."COMPETITION" ("OID");


-- Competition_Team [rel11]
alter table "APP"."TEAM"  add column  "COMPETITION_OID"  integer;
alter table "APP"."TEAM"   add constraint FK_TEAM_COMPETITION foreign key ("COMPETITION_OID") references "APP"."COMPETITION" ("OID");


-- Competition_Team_2 [rel12]
create table "APP"."COMPETITION_TEAM_2" (
   "COMPETITION_OID"  integer not null,
   "TEAM_OID"  integer not null,
  primary key ("COMPETITION_OID", "TEAM_OID")
);
alter table "APP"."COMPETITION_TEAM_2"   add constraint FK_COMPETITION_TEAM_2_COMPETIT foreign key ("COMPETITION_OID") references "APP"."COMPETITION" ("OID");
alter table "APP"."COMPETITION_TEAM_2"   add constraint FK_COMPETITION_TEAM_2_TEAM foreign key ("TEAM_OID") references "APP"."TEAM" ("OID");


-- Game_Admin [rel2]
create table "APP"."GAME_ADMIN" (
   "GAME_OID"  integer not null,
  primary key ("GAME_OID")
);
alter table "APP"."GAME_ADMIN"   add constraint FK_GAME_ADMIN_GAME foreign key ("GAME_OID") references "APP"."GAME" ("OID");
alter table "APP"."GAME_ADMIN"   add constraint FK_GAME_ADMIN_ADMIN foreign key () references "APP"."ADMIN" ();


-- Team_GameA [rel3]
alter table "APP"."TEAM"  add column  "GAME_OID"  integer;
alter table "APP"."TEAM"   add constraint FK_TEAM_GAME foreign key ("GAME_OID") references "APP"."GAME" ("OID");


-- Team_GameB [rel4]
alter table "APP"."TEAM"  add column  "GAME_OID_2"  integer;
alter table "APP"."TEAM"   add constraint FK_TEAM_GAME_2 foreign key ("GAME_OID_2") references "APP"."GAME" ("OID");


-- Team_Premium [rel5]
create table "APP"."TEAM_PREMIUM" (
   "TEAM_OID"  integer not null,
  primary key ("TEAM_OID")
);
alter table "APP"."TEAM_PREMIUM"   add constraint FK_TEAM_PREMIUM_TEAM foreign key ("TEAM_OID") references "APP"."TEAM" ("OID");
alter table "APP"."TEAM_PREMIUM"   add constraint FK_TEAM_PREMIUM_PREMIUM foreign key () references "APP"."PREMIUM" ();


-- Premium_Player [rel7]
create table "APP"."PREMIUM_PLAYER" (
   "PLAYER_OID"  integer not null,
  primary key ("PLAYER_OID")
);
alter table "APP"."PREMIUM_PLAYER"   add constraint FK_PREMIUM_PLAYER_PREMIUM foreign key () references "APP"."PREMIUM" ();
alter table "APP"."PREMIUM_PLAYER"   add constraint FK_PREMIUM_PLAYER_PLAYER foreign key ("PLAYER_OID") references "APP"."PLAYER" ("OID");


-- Player_Team [rel8]
alter table "APP"."TEAM"  add column  "PLAYER_OID"  integer;
alter table "APP"."TEAM"   add constraint FK_TEAM_PLAYER foreign key ("PLAYER_OID") references "APP"."PLAYER" ("OID");


